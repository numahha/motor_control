import numpy as np
import copy
import matplotlib.pyplot as plt

torque_constant=2.1


current=np.linspace(0.5,2.2,18)*0.1*torque_constant
omega=copy.copy(current)
omega[17]=12.000187
omega[16]=11.127500
omega[15]=10.218857
omega[14]=9.177208
omega[13]=7.391448
omega[12]=6.418501
omega[11]=5.196997
omega[10]=4.258493
omega[9]=3.491814
omega[8]=2.923670
omega[7]=2.379475
omega[6]=1.922092
omega[5]=1.420190
omega[4]=1.074452
omega[3]=0.000000
omega[2]=0.000000
omega[1]=0.000000
omega[0]=0.000000

print(0.1*torque_constant*(2.2-0.8)/12.)

plt.plot(omega,current,label="data")
plt.xlabel('omega [rad/sec]')
plt.plot([0., 12],[0.8*0.1*torque_constant, 2.2*0.1*torque_constant],label="cureve")
plt.ylabel('Torque constant * current [Nm]')
#plt.xlim([-0.1, 8.1])
#plt.ylim([-0.1, 13])
plt.legend()
plt.savefig("gain.png")
plt.show()

